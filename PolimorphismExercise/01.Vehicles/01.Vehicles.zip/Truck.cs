﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles
{
    public class Truck : Vehicle
    {
        private const double TruckFuelConsumptionIncreasement = 1.6;
        public Truck(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity, fuelConsumption + TruckFuelConsumptionIncreasement)
        {
        }

        public override void Refuel(double liters)
        {
            this.FuelQuantity += 0.95 * liters;
        }
    }
}
