﻿using System;

namespace Animals
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            

        }
    }
}
