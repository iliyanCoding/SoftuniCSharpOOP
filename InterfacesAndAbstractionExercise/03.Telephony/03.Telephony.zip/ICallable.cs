﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    public interface ICallable
    {
        string Call(string phoneNumber);
    }
}
